# from flask import Blueprint, render_template

# auth = Blueprint('auth', __name__)

# for simplicity current user id is 1
# @auth.route('/login')
# def login():
#     return render_template('login.html')
#
#
# @auth.route('/logout')
# def logout():
#     return render_template('login.html')
#
#
# @auth.route('/signup')
# def signup():
#     return render_template('signup.html')

