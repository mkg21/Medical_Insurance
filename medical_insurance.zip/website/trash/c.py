# from random import randrange
# x = [(1,'Maria','2000-03-15','female','daughter'),
# (1,'Magy','2003-03-17','female','daughter'),
# (2,'rafat','2008-11-01','male','son'),
# (4,'karim','2005-03-11','male','son'),
# (6,'Maha','2000-12-11','female','daughter'),
# (6,'yara','2007-03-11','female','daughter'),
# (6,'Dina','1975-03-11','female','wife'),
# (7,'ali','2000-01-11','male','son'),
# (7,'Yousef','2002-08-08','male','son'),
# (7,'Taher','1997-03-11','male','son'),
# (7,'Sahar','1977-03-11','female','wife')]
#
# for i in x:
#     res_id = i[0]
#     name = i[1]
#     kinship = i[4]
#     print(f"insert into contract values (DEFAULT, {randrange(1, 4)}, null, {res_id}, '{name}', '{kinship}','Cash, visa');")


